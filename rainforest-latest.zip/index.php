<!DOCTYPE html>
<html lang="en" prefix="og: http://ogp.me/ns#">
<head>
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-138298901-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'UA-138298901-1');
    </script>
    <script type="text/javascript">
    
        if (screen.width <= 699) {

            window.location = "http://m.rainforestigatpuri.com/";

        }

    </script>

    <!--Chatbot-->
    <!-- Chat css & js Start -->
    <link href="https://bot.dbnix.ai/travis/web/lib/css/updated.grid.css" rel="stylesheet" >
    <link rel="canonical" href="https://rainforestigatpuri.com/" />
    <link href="https://bot.dbnix.ai/travis/web/lib/css/font-awesome.min.css" rel="stylesheet" >
    <script src="https://bot.dbnix.ai/travis/web/lib/js/socket.io.js"></script>
    <!-- Chat css & js End -->
    <!--Chatbot-->
    <meta charset="UTF-8">
    <meta name="viewport" content= "width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="img/favicon.ico">
    <title>Best Family Hotels and Resorts in Igatpuri | Rainforest Resort and Spa</title>
    <meta property="og:title" content="Rainforest Resort & Spa, Igatpuri" />
    <meta property="og:image" content="https://rainforestigatpuri.com/img/bg1_1.jpg" />
    <meta property="og:image:secure_url" content="https://rainforestigatpuri.com/img/bg1_1.jpg" />
    <meta property="og:image:type" content="image/jpeg" />
    <meta property="og:image:width" content="400" />
    <meta property="og:image:height" content="300" />
    <meta property="og:image:alt" content="Welcome to Rainforest Resort & Spa, Igatpuri" />
    <meta property="og:title" content="Rooms at Rainforest Resort & Spa, Igatpuri" />
    <meta property="og:image" content="https://rainforestigatpuri.com/img/rooms/luxury/luxury_room1.jpg" />
    <meta property="og:image:secure_url" content="https://rainforestigatpuri.com/img/rooms/luxury/luxury_room1.jpg" />
    <meta property="og:image:type" content="image/jpeg" />
    <meta property="og:image:width" content="400" />
    <meta property="og:image:height" content="300" />
    <meta property="og:image:alt" content="Rainforest Resort & Spa offers a range of accommodations suitable for every type of guests." />
    <meta name="description" content="Welcome to Rainforest resort best family hotels and resort with Swimming Pool in igatpuri 40 acres of Switzerland!! Yes that’s correct Rainforest resort is located at the peaceful and most serene location of Igatpuri Go Offline and unwinds yourself in the lush green resort overlooking mountains of Igatpuri">
    <meta name="keywords" content="Best resort near Mumbai, resort near Mumbai, vipassana igatpuri, igatpuri, igatpuri to mumbai, igatpuri hotels, rainforest resort igatpuri, resorts near igatpuri, igatpuri hotels, igatpuri resorts, igatpuri villas, places to visit in igatpuri, mumbai to igatpuri, resorts in nashik,resort in igatpuri with swimming pool,hotel and resort in igatpuri,holiday resorts in igatpuri,.budget resort in igatpuri,.book resort in igatpuri,.best family resort in igatpuri,resorts in igatpuri for one day picnic,resort in igatpuri for group,resorts in igatpuri for family,resorts in igatpuri for family,resorts in igatpuri for overnight stay,famous resort in igatpuri,resort in igatpuri maharashtra,resort near igatpuri station,villa resort in igatpuri,">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://kit.fontawesome.com/251d3a1e2b.js" crossorigin="anonymous"></script>
    <style>
    .snowflake {
        color: rgb(161, 0, 0);
   font-size: 1em;
   font-family: Arial, sans-serif;
   text-shadow: 0 0 5px #000;
 }
 @-webkit-keyframes snowflakes-fall{0%{top:-10%}100%{top:100%}}@-webkit-keyframes snowflakes-shake{0%{-webkit-transform:translateX(0px);transform:translateX(0px)}50%{-webkit-transform:translateX(80px);transform:translateX(80px)}100%{-webkit-transform:translateX(0px);transform:translateX(0px)}}@keyframes snowflakes-fall{0%{top:-10%}100%{top:100%}}@keyframes snowflakes-shake{0%{transform:translateX(0px)}50%{transform:translateX(80px)}100%{transform:translateX(0px)}}.snowflake{position:fixed;top:-10%;z-index:9999;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;cursor:default;-webkit-animation-name:snowflakes-fall,snowflakes-shake;-webkit-animation-duration:10s,3s;-webkit-animation-timing-function:linear,ease-in-out;-webkit-animation-iteration-count:infinite,infinite;-webkit-animation-play-state:running,running;animation-name:snowflakes-fall,snowflakes-shake;animation-duration:10s,3s;animation-timing-function:linear,ease-in-out;animation-iteration-count:infinite,infinite;animation-play-state:running,running}.snowflake:nth-of-type(0){left:1%;-webkit-animation-delay:0s,0s;animation-delay:0s,0s}.snowflake:nth-of-type(1){left:10%;-webkit-animation-delay:1s,1s;animation-delay:1s,1s}.snowflake:nth-of-type(2){left:20%;-webkit-animation-delay:6s,.5s;animation-delay:6s,.5s}.snowflake:nth-of-type(3){left:30%;-webkit-animation-delay:4s,2s;animation-delay:4s,2s}.snowflake:nth-of-type(4){left:40%;-webkit-animation-delay:2s,2s;animation-delay:2s,2s}.snowflake:nth-of-type(5){left:50%;-webkit-animation-delay:8s,3s;animation-delay:8s,3s}.snowflake:nth-of-type(6){left:60%;-webkit-animation-delay:6s,2s;animation-delay:6s,2s}.snowflake:nth-of-type(7){left:70%;-webkit-animation-delay:2.5s,1s;animation-delay:2.5s,1s}.snowflake:nth-of-type(8){left:80%;-webkit-animation-delay:1s,0s;animation-delay:1s,0s}.snowflake:nth-of-type(9){left:90%;-webkit-animation-delay:3s,1.5s;animation-delay:3s,1.5s}
/* Demo Purpose Only*/
 </style>

</head>
<body>
<div class="snowflakes" aria-hidden="true">
    <div class="snowflake">
      ❤
      </div>
    <div class="snowflake">
      ❤
      </div>
    <div class="snowflake">
      ❤
    </div>
    <div class="snowflake">
      ❤
    </div>
    <div class="snowflake">
      ❤
      </div>
    <div class="snowflake">
      ❤
    </div>
    <div class="snowflake">
      ❤
    </div>
    <div class="snowflake">
      ❤
      </div>
    <div class="snowflake">
      ❤
    </div>
    <div class="snowflake">
      ❤
    </div>
  </div>  
<?php include 'header-rainforest.php' ?>


<section class="container-fluid">
    <div id="player-overlay">
        <video id="vid" style="width: 100%; max-height: 100%;" playsinline autoplay muted loop>
            <source src="img/rf_video.mp4" type="video/mp4" />
            Your browser does not support the video tag.
        </video>
    </div>
    <script>
        document.getElementById('vid').play();
    </script>
    <div class="content" style="position: absolute;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    color: #f1f1f1;
    width: 25%;
    padding: 20px;">
  <p>
  <ul>
    <li>Travel with Confidence during Covid-19</li>
    <li>Private Pool available</li>
    <li>WiFi only at Reception</li>
    <li>Committed to Cleanliness</li>
    <li>No Room Service</li>
 </ul>
</p>
  

</div>
</section>

<section class="container-fluid" style="height: 50px;margin-top:-7px ;  background-color: #aba4a4 ;display: flex; justify-content: center; align-items: center;">
        <div class="text-center">
            <h3><b>Our Highest Priority is health, safety and security of our guests, employees and Business Partners.</b></h3>
        </div>
</section>

<section class="container">
    <div class="home-main">
        <div class="text-center">
            <h2>Rainforest Resort & Spa, Igatpuri</h2>
            <p>40 acres of Switzerland.!! Yes, that's correct Rainforest resort and spa is located in one of the most peaceful & Serene location of Igatpuri. Go Offline and unwind yourself in the lush green resort overlooking mountains of Igatpuri. There is so much to do at Rainforest Resort we are a destination in itself with so much offerings we become one of the most preferred vacation spot for your short holiday.</p>
            <p><b>Book Your Stay at the best resort in Igatpuri!</b></p>
        </div>
    </div>
</section>

<section class="container" id="rooms-section">
    <div class="home-accommodation">
        <div class="text-center">
            <h2>Accommodation</h2>
            <p>We offer a range of accommodations suitable for every type of guests.</p>
        </div>
        <nav>
            <div class="nav nav-pills nav-fill flex-column flex-sm-row" id="nav-tab" role="tablist">
                <a class="nav-item nav-link active text-uppercase" id="deluxe-room-tab" data-toggle="tab" href="#deluxe-room" role="tab" aria-controls="nav-home" aria-selected="true">Deluxe Rooms</a>
                <a class="nav-item nav-link text-uppercase" id="superior-room-tab" data-toggle="tab" href="#superior-room" role="tab" aria-controls="nav-contact" aria-selected="false">Superior Rooms</a>
                <a class="nav-item nav-link text-uppercase" id="one-bedroom-tab" data-toggle="tab" href="#one-bedroom" role="tab" aria-controls="nav-contact" aria-selected="false">One Bedroom Hall Villas</a>
                <a class="nav-item nav-link text-uppercase" id="two-bedroom-tab" data-toggle="tab" href="#two-bedroom" role="tab" aria-controls="nav-contact" aria-selected="false">Two Bedroom Hall Villas</a>
                <a class="nav-item nav-link text-uppercase" id="one-group-tab" data-toggle="tab" href="#one-group" role="tab" aria-controls="nav-contact" aria-selected="false">One Bedroom Group Villas</a>
                <a class="nav-item nav-link text-uppercase" id="two-group-tab" data-toggle="tab" href="#two-group" role="tab" aria-controls="nav-contact" aria-selected="false">Two Bedroom Group Villas</a>
                <a class="nav-item nav-link text-uppercase" id="three-group-tab" data-toggle="tab" href="#three-group" role="tab" aria-controls="nav-contact" aria-selected="false">Three Bedroom Group Villas</a>
                <a class="nav-item nav-link text-uppercase" id="four-group-tab" data-toggle="tab" href="#four-group" role="tab" aria-controls="nav-contact" aria-selected="false">Four Bedroom Group Villas</a>
                <a class="nav-item nav-link text-uppercase" id="luxury-room-tab" data-toggle="tab" href="#luxury-room" role="tab" aria-controls="nav-contact" aria-selected="false">Luxury Room With Mountain View</a>
                <a class="nav-item nav-link text-uppercase" id="family-room-tab" data-toggle="tab" href="#family-room" role="tab" aria-controls="nav-contact" aria-selected="false">Family Cottages</a>
            </div>
        </nav>
        <div class="tab-content" id="nav-tabContent">
            <div class="tab-pane fade show active" id="deluxe-room" role="tabpanel" aria-labelledby="deluxe-room-tab">
                <div class="room-tab">
                    <div class="text-center">
                        <div class="row">
                            <div class="col-md-6">
                                <div id="demo" class="carousel slide" data-ride="carousel">

                                    <!-- Indicators -->
                                    <ul class="carousel-indicators">
                                        <li data-target="#demo" data-slide-to="0" class="active"></li>
                                        <li data-target="#demo" data-slide-to="1"></li>
                                        <li data-target="#demo" data-slide-to="2"></li>
                                    </ul>

                                    <!-- The slideshow -->
                                    <div class="carousel-inner">
                                        <div class="carousel-item active">
                                            <img src="img/rooms/deluxe/Deluxe_room_1.jpg" class="img-fluid" alt="Los Angeles">
                                        </div>
                                        <div class="carousel-item">
                                            <img src="img/rooms/deluxe/Deluxe_room_3.jpg" class="img-fluid" alt="Los Angeles">
                                        </div>
                                        <div class="carousel-item">
                                            <img src="img/rooms/deluxe/Deluxe_room_7.jpg" class="img-fluid" alt="Los Angeles">
                                        </div>
                                    </div>

                                    <!-- Left and right controls -->
                                    <a class="carousel-control-prev" href="#demo" data-slide="prev">
                                        <span class="carousel-control-prev-icon"></span>
                                    </a>
                                    <a class="carousel-control-next" href="#demo" data-slide="next">
                                        <span class="carousel-control-next-icon"></span>
                                    </a>

                                </div>
                            </div>
                            <div class="col-md-6 flexo-nav">
                                <h3>Deluxe Room</h3>
                                <p>The Deluxe Room at RainForest Resort and Spa, Igatpuri, is a classy accommodation which is wonderfully furnished and well-maintained. The neat decor and the comfortable bed makes it a great room with a fabulous view.</p>
                                <p>For Bookings contact at <a href="tel:+91 70210 66877">+91 70210 66877</a></p>
                                <!-- <p><a href="https://secure.staah.com/common-cgi/package/packagebooking.pl?propertyId=1870" class="btn btn-primary">Book Now</a></p> -->
                                <p><a href="https://secure.staah.com/common-cgi/package/packagebooking.pl?propertyId=1870" class="btn btn-primary" style="padding: 10px 24px; border-radius: 7px; border: 2px solid">Book Now</a></p>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="superior-room" role="tabpanel" aria-labelledby="superior-room-tab">
                <div class="room-tab">
                    <div class="text-center">
                        <div class="row">
                            <div class="col-md-6">
                                <div id="demo2" class="carousel slide" data-ride="carousel">

                                    <!-- Indicators -->
                                    <ul class="carousel-indicators">
                                        <li data-target="#demo2" data-slide-to="0" class="active"></li>
                                        <li data-target="#demo2" data-slide-to="1"></li>
                                        <li data-target="#demo2" data-slide-to="2"></li>
                                    </ul>

                                    <!-- The slideshow -->
                                    <div class="carousel-inner">
                                        <div class="carousel-item active">
                                            <img src="img/rooms/superior/superior_room1.jpg" class="img-fluid" alt="Los Angeles">
                                        </div>
                                        <div class="carousel-item">
                                            <img src="img/rooms/superior/superior_room2.jpg" class="img-fluid" alt="Los Angeles">
                                        </div>
                                        <div class="carousel-item">
                                            <img src="img/rooms/superior/superior_room.jpg" class="img-fluid" alt="Los Angeles">
                                        </div>
                                    </div>

                                    <!-- Left and right controls -->
                                    <a class="carousel-control-prev" href="#demo2" data-slide="prev">
                                        <span class="carousel-control-prev-icon"></span>
                                    </a>
                                    <a class="carousel-control-next" href="#demo2" data-slide="next">
                                        <span class="carousel-control-next-icon"></span>
                                    </a>

                                </div>
                            </div>
                            <div class="col-md-6 flexo-nav">
                                <h3>Superior Rooms</h3>
                                <p>Superior rooms are all furnished with modern designer furnishings and have Italian marble bathrooms. Some of the rooms have a furnished balcony offering panoramic views.</p>
                                <p>For Bookings contact at <a href="tel:+91 70210 66877">+91 70210 66877</a></p>
                                <!-- <p><a href="https://secure.staah.com/common-cgi/package/packagebooking.pl?propertyId=1870" class="btn btn-primary">Book Now</a></p> -->
                                <p><a href="https://secure.staah.com/common-cgi/package/packagebooking.pl?propertyId=1870" class="btn btn-primary" style="padding: 10px 24px; border-radius: 7px; border: 2px solid">Book Now</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="one-bedroom" role="tabpanel" aria-labelledby="one-bedroom-tab">
                <div class="room-tab">
                    <div class="text-center">
                        <div class="row">
                            <div class="col-md-6">
                                <div id="demo6" class="carousel slide" data-ride="carousel">

                                    <!-- Indicators -->
                                    <ul class="carousel-indicators">
                                        <li data-target="#demo6" data-slide-to="0" class="active"></li>
                                        <li data-target="#demo6" data-slide-to="1"></li>
                                        <li data-target="#demo6" data-slide-to="2"></li>
                                    </ul>

                                    <!-- The slideshow -->
                                    <div class="carousel-inner">
                                        <div class="carousel-item active">
                                            <img src="img/rooms/onebedroom/one_bedroom_3.jpg" class="img-fluid" alt="Los Angeles">
                                        </div>
                                        <div class="carousel-item">
                                            <img src="img/rooms/onebedroom/one_bedroom_2.jpg" class="img-fluid" alt="Los Angeles">
                                        </div>
                                        <div class="carousel-item">
                                            <img src="img/rooms/onebedroom/one_bedroom_1.jpg" class="img-fluid" alt="Los Angeles">
                                        </div>
                                    </div>

                                    <!-- Left and right controls -->
                                    <a class="carousel-control-prev" href="#demo6" data-slide="prev">
                                        <span class="carousel-control-prev-icon"></span>
                                    </a>
                                    <a class="carousel-control-next" href="#demo6" data-slide="next">
                                        <span class="carousel-control-next-icon"></span>
                                    </a>

                                </div>
                            </div>
                            <div class="col-md-6 flexo-nav">
                                <h3>One Bedroom Hall Villa</h3>
                                <p>One Bedroom Villa is a luxurious and spacious villa with two rooms, a hall and a bedroom. The hall is provided with sofas, television and dining table. The bedroom has a big king size bed.</p>
                                <p>For Bookings contact at <a href="tel: +91 70210 66877"+>91 86555 56688</a></p>
                                <p><a href="https://secure.staah.com/common-cgi/package/packagebooking.pl?propertyId=1870" class="btn btn-primary" style="padding: 10px 24px; border-radius: 7px; border: 2px solid">Book Now</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="two-bedroom" role="tabpanel" aria-labelledby="two-bedroom-tab">
                <div class="room-tab">
                    <div class="text-center">
                        <div class="row">
                            <div class="col-md-6">
                                <div id="demo7" class="carousel slide" data-ride="carousel">

                                    <!-- Indicators -->
                                    <ul class="carousel-indicators">
                                        <li data-target="#demo7" data-slide-to="0" class="active"></li>
                                        <li data-target="#demo7" data-slide-to="1"></li>
                                        <li data-target="#demo7" data-slide-to="2"></li>
                                    </ul>

                                    <!-- The slideshow -->
                                    <div class="carousel-inner">
                                        <div class="carousel-item active">
                                            <img src="img/rooms/twobedroom/two_bedroom_2.jpg" class="img-fluid" alt="Los Angeles">
                                        </div>
                                        <div class="carousel-item">
                                            <img src="img/rooms/twobedroom/two_bedroom_3.jpg" class="img-fluid" alt="Los Angeles">
                                        </div>
                                        <div class="carousel-item">
                                            <img src="img/rooms/twobedroom/two_bedroom_1.jpg" class="img-fluid" alt="Los Angeles">
                                        </div>
                                    </div>

                                    <!-- Left and right controls -->
                                    <a class="carousel-control-prev" href="#demo7" data-slide="prev">
                                        <span class="carousel-control-prev-icon"></span>
                                    </a>
                                    <a class="carousel-control-next" href="#demo7" data-slide="next">
                                        <span class="carousel-control-next-icon"></span>
                                    </a>

                                </div>
                            </div>
                            <div class="col-md-6 flexo-nav">
                                <h3>Two Bedroom Hall Villa</h3>
                                <p>The two-bedroom villa is a posh arrangement for a classy you. With ample space and great fabrics and furnishing, this accommodation type is a clear winner! These rooms provide you privacy and world-class amenities.</p>
                                <p>For Bookings contact at <a href="tel: +91 70210 66877">+91 70210 66877</a></p>
                                <p><a href="https://secure.staah.com/common-cgi/package/packagebooking.pl?propertyId=1870" class="btn btn-primary" style="padding: 10px 24px; border-radius: 7px; border: 2px solid">Book Now</a></p>

                                <!-- <p><a href="https://secure.staah.com/common-cgi/package/packagebooking.pl?propertyId=1870" class="btn btn-primary">Book Now</a></p> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="one-group" role="tabpanel" aria-labelledby="one-group-tab">
                <div class="room-tab">
                    <div class="text-center">
                        <div class="row">
                            <div class="col-md-6">
                                <div id="demo8" class="carousel slide" data-ride="carousel">

                                    <!-- Indicators -->
                                    <ul class="carousel-indicators">
                                        <li data-target="#demo8" data-slide-to="0" class="active"></li>
                                        <li data-target="#demo8" data-slide-to="1"></li>
                                        <li data-target="#demo8" data-slide-to="2"></li>
                                    </ul>

                                    <!-- The slideshow -->
                                    <div class="carousel-inner">
                                        <div class="carousel-item active">
                                            <img src="img/rooms/onegroup/onebedroomgroupvilla1.jpg" class="img-fluid" alt="Los Angeles">
                                        </div>
                                        <div class="carousel-item">
                                            <img src="img/rooms/onegroup/onebedroomgroupvilla2.jpg" class="img-fluid" alt="Los Angeles">
                                        </div>
                                        <div class="carousel-item">
                                            <img src="img/rooms/onegroup/onebedroomgroupvilla3.jpg" class="img-fluid" alt="Los Angeles">
                                        </div>
                                    </div>

                                    <!-- Left and right controls -->
                                    <a class="carousel-control-prev" href="#demo8" data-slide="prev">
                                        <span class="carousel-control-prev-icon"></span>
                                    </a>
                                    <a class="carousel-control-next" href="#demo8" data-slide="next">
                                        <span class="carousel-control-next-icon"></span>
                                    </a>

                                </div>
                            </div>
                            <div class="col-md-6 flexo-nav">
                                <h3>One Bedroom Group Villa</h3>
                                <p>The room surrounded by perfect views of mountains, with a perfect combination of comfort and best amenities; the one bedroom group villa is a marvellous and spacious air-conditioned room with 1 king size bed and three queen size beds. It has a seperate living room with a TV and a wardrobe.</p>
                                <p>For Bookings contact at <a href="tel:+91 70210 66877">+91 70210 66877</a></p>
                                <p><a href="https://secure.staah.com/common-cgi/package/packagebooking.pl?propertyId=1870" class="btn btn-primary" style="padding: 10px 24px; border-radius: 7px; border: 2px solid">Book Now</a></p>
                                
                                <!-- <p><a href="https://secure.staah.com/common-cgi/package/packagebooking.pl?propertyId=1870" class="btn btn-primary">Book Now</a></p> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="two-group" role="tabpanel" aria-labelledby="two-group-tab">
                <div class="room-tab">
                    <div class="text-center">
                        <div class="row">
                            <div class="col-md-6">
                                <div id="demo9" class="carousel slide" data-ride="carousel">

                                    <!-- Indicators -->
                                    <ul class="carousel-indicators">
                                        <li data-target="#demo9" data-slide-to="0" class="active"></li>
                                        <li data-target="#demo9" data-slide-to="1"></li>
                                        <li data-target="#demo9" data-slide-to="2"></li>
                                    </ul>

                                    <!-- The slideshow -->
                                    <div class="carousel-inner">
                                        <div class="carousel-item active">
                                            <img src="img/rooms/twogroup/groupvilla1.jpg" class="img-fluid" alt="Los Angeles">
                                        </div>
                                        <div class="carousel-item">
                                            <img src="img/rooms/twogroup/groupvilla.jpg" class="img-fluid" alt="Los Angeles">
                                        </div>
                                        <div class="carousel-item">
                                            <img src="img/rooms/twogroup/groupvilla2.jpg" class="img-fluid" alt="Los Angeles">
                                        </div>
                                    </div>

                                    <!-- Left and right controls -->
                                    <a class="carousel-control-prev" href="#demo9" data-slide="prev">
                                        <span class="carousel-control-prev-icon"></span>
                                    </a>
                                    <a class="carousel-control-next" href="#demo9" data-slide="next">
                                        <span class="carousel-control-next-icon"></span>
                                    </a>

                                </div>
                            </div>
                            <div class="col-md-6 flexo-nav">
                                <h3>Two Bedroom Group Villa</h3>
                                <p>This marvellous and spacious air-conditioned room comes with two king-sized bed and three queen-sized beds. It has a separate living room, a TV and a wardrobe. It is luxurious and tranquil at the same time.</p>
                                <p>For Bookings contact at <a href="tel: +91 70210 66877">+91 70210 66877</a></p>
                                <p><a href="https://secure.staah.com/common-cgi/package/packagebooking.pl?propertyId=1870" class="btn btn-primary" style="padding: 10px 24px; border-radius: 7px; border: 2px solid">Book Now</a></p>
                                <!-- <p><a href="https://secure.staah.com/common-cgi/package/packagebooking.pl?propertyId=1870" class="btn btn-primary">Book Now</a></p> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="three-group" role="tabpanel" aria-labelledby="three-group-tab">
                <div class="room-tab">
                    <div class="text-center">
                        <div class="row">
                            <div class="col-md-6">
                                <div id="demo11" class="carousel slide" data-ride="carousel">

                                    <!-- Indicators -->
                                    <ul class="carousel-indicators">
                                        <li data-target="#demo11" data-slide-to="0" class="active"></li>
                                        <li data-target="#demo11" data-slide-to="1"></li>
                                        <li data-target="#demo11" data-slide-to="2"></li>
                                    </ul>

                                    <!-- The slideshow -->
                                    <div class="carousel-inner">
                                        <div class="carousel-item active">
                                            <img src="img/rooms/fourbedroom/4bhkHall.jpg" class="img-fluid" alt="Los Angeles">
                                        </div>
                                        <div class="carousel-item">
                                            <img src="img/rooms/fourbedroom/4BHKHall3.jpg" class="img-fluid" alt="Los Angeles">
                                        </div>
                                        <div class="carousel-item">
                                            <img src="img/rooms/fourbedroom/4BHKBedroom.jpg" class="img-fluid" alt="Los Angeles">
                                        </div>
                                    </div>

                                    <!-- Left and right controls -->
                                    <a class="carousel-control-prev" href="#demo11" data-slide="prev">
                                        <span class="carousel-control-prev-icon"></span>
                                    </a>
                                    <a class="carousel-control-next" href="#demo11" data-slide="next">
                                        <span class="carousel-control-next-icon"></span>
                                    </a>

                                </div>
                            </div>
                            <div class="col-md-6 flexo-nav">
                                <h3>Three Bedroom Group Villa</h3>
                                <p>This marvellous and spacious air-conditioned room comes with three king-sized bed. It has a separate living room, a TV and a wardrobe. It is luxurious and tranquil at the same time.</p>
                                <p>For Bookings contact at <a href="tel:+91 70210 66877">+91 70210 66877</a></p>
                                <p><a href="https://secure.staah.com/common-cgi/package/packagebooking.pl?propertyId=1870" class="btn btn-primary" style="padding: 10px 24px; border-radius: 7px; border: 2px solid">Book Now</a></p>
                                <!-- <p><a href="https://secure.staah.com/common-cgi/package/packagebooking.pl?propertyId=1870" class="btn btn-primary">Book Now</a></p> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="four-group" role="tabpanel" aria-labelledby="four-group-tab">
                <div class="room-tab">
                    <div class="text-center">
                        <div class="row">
                            <div class="col-md-6">
                                <div id="demo12" class="carousel slide" data-ride="carousel">

                                    <!-- Indicators -->
                                    <ul class="carousel-indicators">
                                        <li data-target="#demo12" data-slide-to="0" class="active"></li>
                                        <li data-target="#demo12" data-slide-to="1"></li>
                                        <li data-target="#demo12" data-slide-to="2"></li>
                                        <li data-target="#demo12" data-slide-to="3"></li>
                                    </ul>

                                    <!-- The slideshow -->
                                    <div class="carousel-inner">
                                        <div class="carousel-item active">
                                            <img src="img/rooms/fourbedroom/4BHKHall4.jpg" class="img-fluid" alt="Los Angeles">
                                        </div>
                                        <div class="carousel-item">
                                            <img src="img/rooms/fourbedroom/4BHKHall5.jpg" class="img-fluid" alt="Los Angeles">
                                        </div>
                                        <div class="carousel-item">
                                            <img src="img/rooms/fourbedroom/4BHKBedroom5.jpg" class="img-fluid" alt="Los Angeles">
                                        </div>
                                        <div class="carousel-item">
                                            <img src="img/rooms/fourbedroom/4BHKBedroom9.jpg" class="img-fluid" alt="Los Angeles">
                                        </div>
                                    </div>

                                    <!-- Left and right controls -->
                                    <a class="carousel-control-prev" href="#demo12" data-slide="prev">
                                        <span class="carousel-control-prev-icon"></span>
                                    </a>
                                    <a class="carousel-control-next" href="#demo12" data-slide="next">
                                        <span class="carousel-control-next-icon"></span>
                                    </a>

                                </div>
                            </div>
                            <div class="col-md-6 flexo-nav">
                                <h3>Four Bedroom Group Villa</h3>
                                <p>This marvellous and spacious air-conditioned room comes with four king-sized beds. It has a separate living room, a TV and a wardrobe. It is luxurious and tranquil at the same time.</p>
                                <p>For Bookings contact at <a href="tel: +91 70210 66877">+91 70210 66877</a></p>
                                <p><a href="https://secure.staah.com/common-cgi/package/packagebooking.pl?propertyId=1870" class="btn btn-primary" style="padding: 10px 24px; border-radius: 7px; border: 2px solid">Book Now</a></p>
                                
                                <!-- <p><a href="https://secure.staah.com/common-cgi/package/packagebooking.pl?propertyId=1870" class="btn btn-primary">Book Now</a></p> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="luxury-room" role="tabpanel" aria-labelledby="luxury-rooom-tab">
                <div class="room-tab">
                    <div class="text-center">
                        <div class="row">
                            <div class="col-md-6">
                                <div id="demo10" class="carousel slide" data-ride="carousel">

                                    <!-- Indicators -->
                                    <ul class="carousel-indicators">
                                        <li data-target="#demo10" data-slide-to="0" class="active"></li>
                                        <li data-target="#demo10" data-slide-to="1"></li>
                                        <li data-target="#demo10" data-slide-to="2"></li>
                                    </ul>

                                    <!-- The slideshow -->
                                    <div class="carousel-inner">
                                        <div class="carousel-item active">
                                            <img src="img/rooms/luxury_rooms/luxury_room_with_mountain_view_1.jpeg" class="img-fluid" alt="Los Angeles">
                                        </div>
                                        <div class="carousel-item">
                                            <img src="img/rooms/luxury_rooms/luxury_room_with_mountain_view_2.jpeg" class="img-fluid" alt="Los Angeles">
                                        </div>
                                        <div class="carousel-item">
                                            <img src="img/rooms/luxury_rooms/luxury_room_with_mountain_view_4.jpeg" class="img-fluid" alt="Los Angeles">
                                        </div>
                                    </div>

                                    <!-- Left and right controls -->
                                    <a class="carousel-control-prev" href="#demo10" data-slide="prev">
                                        <span class="carousel-control-prev-icon"></span>
                                    </a>
                                    <a class="carousel-control-next" href="#demo10" data-slide="next">
                                        <span class="carousel-control-next-icon"></span>
                                    </a>

                                </div>
                            </div>
                            <div class="col-md-6 flexo-nav">
                                <h3>Luxury Room with Mountain View</h3>
                                <p>Our luxury room is well-furnished spacious and it comes with private balcony, the scenic view of the mountains from the Room will leave you spell bounded. All modern amenities are part of luxury room.</p>
                                <p>For Bookings contact at <a href="tel: 02240155555">022 40155555</a></p>
                                <p><a href="https://secure.staah.com/common-cgi/package/packagebooking.pl?propertyId=1870" class="btn btn-primary" style="padding: 10px 24px; border-radius: 7px; border: 2px solid">Book Now</a></p>
                                <!-- <p><a href="https://secure.staah.com/common-cgi/package/packagebooking.pl?propertyId=1870" class="btn btn-primary">Book Now</a></p> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="family-room" role="tabpanel" aria-labelledby="family-rooom-tab">
                <div class="room-tab">
                    <div class="text-center">
                        <div class="row">
                            <div class="col-md-6">
                                <div id="demo10" class="carousel slide" data-ride="carousel">

                                    <!-- Indicators -->
                                    <ul class="carousel-indicators">
                                        <li data-target="#demo10" data-slide-to="0" class="active"></li>
                                        <li data-target="#demo10" data-slide-to="1"></li>
                                        <li data-target="#demo10" data-slide-to="2"></li>
                                    </ul>

                                    <!-- The slideshow -->
                                    <div class="carousel-inner">
                                        <div class="carousel-item active">
                                            <img src="img/rooms/familycottage/familycottage1.jpg" class="img-fluid" alt="Los Angeles">
                                        </div>
                                        <div class="carousel-item">
                                            <img src="img/rooms/familycottage/Family_cottage_2.jpg" class="img-fluid" alt="Los Angeles">
                                        </div>
                                        <div class="carousel-item">
                                            <img src="img/rooms/familycottage/Family_cottage_1.jpg" class="img-fluid" alt="Los Angeles">
                                        </div>
                                    </div>

                                    <!-- Left and right controls -->
                                    <a class="carousel-control-prev" href="#demo10" data-slide="prev">
                                        <span class="carousel-control-prev-icon"></span>
                                    </a>
                                    <a class="carousel-control-next" href="#demo10" data-slide="next">
                                        <span class="carousel-control-next-icon"></span>
                                    </a>

                                </div>
                            </div>
                            <div class="col-md-6 flexo-nav">
                                <h3>Family Cottage</h3>
                                <p>Ideal for family travelers, who wants to experience cottage style accommodation in the midst of Mountain. 6 guest can easily accomodate in our family cottage.</p>
                                <p>For Bookings contact at <a href="tel: +91 70210 66877">+91 70210 66877</a></p>
                                <p><a href="https://secure.staah.com/common-cgi/package/packagebooking.pl?propertyId=1870" class="btn btn-primary" style="padding: 10px 24px; border-radius: 7px; border: 2px solid">Book Now</a></p>
                                <!-- <p><a href="https://secure.staah.com/common-cgi/package/packagebooking.pl?propertyId=1870" class="btn btn-primary">Book Now</a></p> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

        <hr>         
        <section class="container" >
        <div class="text-center">
            <h4><strong> Rainforest Resort and Spa is highly recommended and approved by the Maharashtra Tourism Development Corporation (MTDC). Igatpuri is known for 100% Fresh oxygen and Pure Air, we are now open with all preventive measure that is set by the Government, this is the best time to visit Igatpuri, the weather is absolutely Pleasant and favorable. </strong></h4>        </div>
</section> 
        <hr>

<section class="container">
    <div class="home-accommodation">
        <div class="text-center">
            <h2>Facilities</h2>
            <!-- <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci delectus expedita fugit iure suscipit vero.</p> -->
        </div>
        <nav>
            <div class="nav nav-pills nav-fill flex-column flex-sm-row" id="nav-tab1" role="tablist">
                <a class="nav-item nav-link active text-uppercase" id="restaurant-tab" data-toggle="tab" href="#restaurant-section" role="tab" aria-controls="nav-home1" aria-selected="true">Timber Restaurant</a>
                <a class="nav-item nav-link text-uppercase" id="corporate-tab" data-toggle="tab" href="#corporate-section" role="tab" aria-controls="nav-profile1" aria-selected="false">Corporate</a>
            </div>
        </nav>
        <div class="tab-content" id="nav-tabContent1">
            <div class="tab-pane fade show active" id="restaurant-section" role="tabpanel" aria-labelledby="restaurant-tab">
                <div class="room-tab">
                    <div class="text-center">
                        <div class="row">
                            <div class="col-md-6 flexo-nav">
                                <h3>Timber Restaurant</h3>
                                <p>RainForest Resort and Spa, Igatpuri, has the best in-house restaurant that serves authentic Indian, Chinese, Mughlai, Tandoori and Punjabi delicacies that will tickle your taste buds and satisfy your hunger pangs at any time of the day! Operating from 8 a.m. to 10.30 p.m. Our restaurant has a lovely view of the mesmerizing scenic beauty of Igatpuri. While you enjoy your flavoursome meal, you can see the gorgeous misty hills and lush green lawns stretched out across your sight.</p>
                                <p><a href="https://secure.staah.com/common-cgi/package/packagebooking.pl?propertyId=1870" class="btn btn-primary" style="padding: 10px 24px; border-radius: 7px; border: 2px solid">Book Now</a></p>
                            </div>
                            <div class="col-md-6">
                                <div id="demo4" class="carousel slide" data-ride="carousel">

                                    <!-- Indicators -->
                                    <ul class="carousel-indicators">
                                        <li data-target="#demo4" data-slide-to="0" class="active"></li>
                                        <li data-target="#demo4" data-slide-to="1"></li>
                                        <li data-target="#demo4" data-slide-to="2"></li>
                                    </ul>

                                    <!-- The slideshow -->
                                    <div class="carousel-inner">
                                        <div class="carousel-item active">
                                            <img src="img/restaurant/timber_restaurant.jpg" class="img-fluid" alt="Los Angeles">
                                        </div>
                                        <div class="carousel-item">
                                            <img src="img/restaurant/rainforest_restaurant.jpg" class="img-fluid" alt="Los Angeles">
                                        </div>
                                        <div class="carousel-item">
                                            <img src="img/restaurant/restaurant_in_igatpuri.jpg" class="img-fluid" alt="Los Angeles">
                                        </div>
                                    </div>

                                    <!-- Left and right controls -->
                                    <a class="carousel-control-prev" href="#demo4" data-slide="prev">
                                        <span class="carousel-control-prev-icon"></span>
                                    </a>
                                    <a class="carousel-control-next" href="#demo4" data-slide="next">
                                        <span class="carousel-control-next-icon"></span>
                                    </a>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="corporate-section" role="tabpanel" aria-labelledby="corporate-tab">
                <div class="room-tab">
                    <div class="text-center">
                        <div class="row">
                            <div class="col-md-6 flexo-nav">
                                <h3>Corporate</h3>
                                <p>Our private and fully equipped meeting facilities and boardrooms offer high class stylish business environments which cater to all your business needs. Meet your partners or hold your business gatherings in the comfort of our corporate business rooms.</p>
                                <p><a href="https://secure.staah.com/common-cgi/package/packagebooking.pl?propertyId=1870" class="btn btn-primary" style="padding: 10px 24px; border-radius: 7px; border: 2px solid">Book Now</a></p>
                            </div>
                            <div class="col-md-6" style="background: url('img/corporate/corporate1.jpg') center center no-repeat; background-size: cover; height: 300px;">
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       
       
    </div>
</section>

<?php include 'callsection.php' ?>

<?php include 'footer-rainforest.php' ?>


<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
<script src="sweetalert2.all.min.js"></script>
<!-- Optional: include a polyfill for ES6 Promises for IE11 -->
<script src="https://cdn.jsdelivr.net/npm/promise-polyfill"></script>
<script src="sweetalert2.min.js"></script>
<link rel="stylesheet" href="sweetalert2.min.css">
<!---
<script>
    Swal.fire({
      // title: '<strong style="color: #000000; text-transform: uppercase">Sorry We\'re closed!</strong>',
      html: '<img src="./img/banner.jpg" class="img-fluid" alt="">',
    });
  </script> -->
<script src="js/script.js"></script> 
</body>
</html>
