<section class="home-other-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6" style="background: url(img/footer.jpeg) center center no-repeat; background-size: cover;"></div>
            <div class="col-md-6 other-content flexo-nav">
            <h2>YOUR BOOKING JUST A CALL AWAY</h2>
                <p><a class="btn btn-primary" href="tel: +91 70210 66877">+91 70210 66877</a></p> <br>
            <ul>
            <li> No E-pass is required to Travel to Igatpuri</li>
            <li>Contact less Check In</li>
            <li>Sanitizers in Common Areas</li>
            <li>Social Distancing</li>
            <li> Temperature Check</li>
            <li>Luggage Sanitization</li>
            </ul>      
            </div>
        </div>
    </div>
</section>